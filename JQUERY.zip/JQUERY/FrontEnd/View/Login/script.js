$(document).ready(function () {
    // Animação ao carregar a pagina
    
    $(".login-container").fadeIn(1200);


    // Clique no botão
    $("#btnLogin").click(async function () { // AQUI QUEBROU
        let email = $("#email").val();
        let senha = $("#senha").val();
        

   
        // esconde mensagem antiga
        $("#mensagem").hide();

        if (email === "" || senha === "") {
            
            mostrarErro("Preencha todos os campos!");
            $("#btnLogin").text("Entrar");
            return;
        };
        
        try {
            
            $("#btnLogin").text("Entrando...");
            const resposta = await fetch("http://localhost:3000/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    nome,
                    email
                })
                
            });

            if (!resposta.ok) {
                mostrarErro("Erro ao logar usuário");
                $("btnLogin").text("Entrar");              
                return;
            }

            $("#mensagem")
                .removeClass("erro")
                .addClass("sucesso")
                .text("Usuario logado com sucesso")
                .fadeIn(500);

            setTimeout(function () {
                window.location.href = "..//home/homepage.html"
            }, 10000)

        } catch (erro) {
            mostrarErro("Erro ao conectar com a API");
            $("btnLogin").text("Entrar");
        }

        function mostrarErro(texto) {
            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text(texto)
                .fadeIn(500);

            $(".register-container")
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "0px" }, 100)
        }
    })
})

function navRegistrar() {
    window.location.href = "../Registrar/registrar.html";
}