$(document).ready(function () {
    
    $(".register-container").fadeIn(800, function () {

        $(".campo").eq(0).slideDown(300, function () {
            $(".campo").eq(1).slideDown(300, function () {
                $(".campo").eq(2).slideDown(300, function () {
                    $(".campo").eq(3).slideDown(300, function () {
                        $("#btnRegistrar").fadeIn(400);
                    })
                })
            })
        })
    });

    

    $("#btnRegistrar").click(async function () {

        

        let nome = $("#nome").val().trim();        
        let email = $("#email").val().trim();       
        let senha = $("#senha").val().trim();        
        let confirmarSenha = $("#confirmaSenha").val().trim();        
        let areaServico = $("#areaServico").val().trim();        
        let setor = $("#setor").val().trim();       
        let usuario = $("#usuario").val().trim();       
        let tipo = $("#tipo").val().trim();       
        let genero = $("input[name= 'genero']:checked").val();        
        let pcd = $("input[name= 'pcd']:checked").val();
        
        

        $("#mensagem").hide()
        

        // Fazer a confirmação de senha
        
        if(nome === "" || email === "" || senha === "" || confirmaSenha === "" || areaServico === "" || setor === "" || usuario === "" || tipo == "" || !genero  || pcd == null) {
            mostrarErro("Complete todos os campos!");
            return;
        }

        
        if (!email.includes("@")) {
            mostrarErro("Digite um e-mail válido!");
            return;
        }

        if (senha.length < 6) {
            mostrarErro("A senha deve ter pelo menos 6 caracteres!")
            return;
        }

        if(confirmarSenha !== senha) {
            mostrarErro("As senhas devem ser iguais!")
            return;
        }
    

        try {
            $("#btnRegistrar").text("Cadastrando...")

            const resposta = await fetch("http://localhost:3000/cadastro", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    nome,
                    email,
                    senha,
                    confirmarSenha,
                    areaServico,
                    setor,
                    usuario,
                    tipo,
                    genero,
                    pcd
                })
            });

            if (!resposta.ok) {
                mostrarErro("Erro ao cadastrar usuário");
                $("#btnRegistrar").text("Cadastrar");
                return;
            }

            $("#mensagem")
            .removeClass("erro")
            .addClass("sucesso")
            .text("Usuario cadastrado com sucesso")
            .fadeIn(500);

            setTimeout(function () {
                window.location.href = "../Registrar/registrar.html"
            }, 1000) // esse numero é o tempo pra abrir a tela em ms 
        } catch (erro) {
            mostrarErro("Erro ao conectar com a API");
            $("btnRegistrar").text("Cadastrar");
        }

        $("#btnRegistrar")
        .text("Cadastrando...")
        slideUp(200)
        .slideDown(200);
    

    function mostrarErro(texto) {
        $("#mensagem")
        .removeClass("sucesso")
        .addClass("erro")
        .text(texto)
        .fadeIn(500);

        $(".register-container")
            .animate({ marginLeft: "-10px" }, 100)
            .animate({ marginLeft: "10px" }, 100)
            .animate({ marginLeft: "-10px" }, 100)
            .animate({ marginLeft: "10px" }, 100)
            .animate({ marginLeft: "0px" }, 100)
    
            }
        })
    })
function navLogin(){
    window.location.href = "../Login/login.html"
}
