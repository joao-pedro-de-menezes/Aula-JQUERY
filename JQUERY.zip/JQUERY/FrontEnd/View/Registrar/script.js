$(document).ready(function () {
    $(".register-container").fadeIn(1200);

    $("#btnRegistrar").click(function () {
        let nome = $("#nome").val().trim();
        let email = $("#email").val().trim();
        let senha = $("#senha").val().trim();
        let confirmaSenha = $("#confirmaSenha").val().trim();
        let areaServico = $("#areaServico").val().trim();
        let setor = $("#setor").val().trim();
        let usuario = $("#usuario").val().trim();
        let tipo = $("#tipo").val().trim();
        let genero = $("#genero").val().trim();
        let pcd = $("#pcd").val().trim();

        $("#mensagem").hide()

        // Fazer a confirmação de senha
        
        if(!nome || !email || !senha || !confirmaSenha || !areaServico || !setor || !usuario || tipo == "" || genero == 0 || pcd == null) {
            $("#mensagem")
            .removeClass("sucesso")
            .addClass("erro")
            .text("Preencha todos os campos")
            .fadeIn(500);

            $(".register-container")
            .animate({ marginLeft: "-10px" }, 100)
            .animate({ marginLeft: "10px" }, 100)
            .animate({ marginLeft: "-10px" }, 100)
            .animate({ marginLeft: "10px" }, 100)
            .animate({ marginLeft: "0px" }, 100)

        } else {
            $("#mensagem")
            .removeClass("erro")
            .addClass("sucesso")
            .text("Registro realizado com sucesso")
            .fadeIn(500)

            $("#btnRegistrar")
            .text("Cadastrando...")
            .slideUp(200)
            .slideDown(200)
        }
    })
})

function navLogin(){
    window.location.href = "../Login/login.html"
}