const express = require("express"); // se usarmos esses CONST sem o "require", dará erro só na hora que for executar o sistema, é o erro invisivel, é obrigatorio usar require 
const cors = require("cors");
const mysql = require("mysql2/promise"); // O "/promise" serve para dizer para o banco de dados como se fosse uma promessa de um valor para ele buscar, algo que existe, é obrigatorio quando usa o "await" no sistema

// CHAMAR O MODULO db.js

const app = express(); // aqui o "app" esta sendo feito para importar os modulos detro do express para usar suas funções   

app.use(express.json); // (aqui esta usando o método "use" que estava dentro do express e que na função de cima ja foi importado pra dentro do app) e tudo que for utilizado com o método "use" será feito no estilo JSON  