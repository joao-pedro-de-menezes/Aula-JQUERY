const express = require("express"); // se usarmos esses CONST sem o "require", dará erro só na hora que for executar o sistema, é o erro invisivel, é obrigatorio usar require 
const cors = require("cors");
 // O "/promise" serve para dizer para o banco de dados como se fosse uma promessa de um valor para ele buscar, algo que existe, é obrigatorio quando usa o "await" no sistema

const db = require("./db")

// CHAMAR O MODULO db.js

const app = express(); // aqui o "app" esta sendo feito para importar os modulos detro do express para usar suas funções   

app.use(express.json()); // (aqui esta usando o método "use" que estava dentro do express e que na função de cima ja foi importado pra dentro do app) e tudo que for utilizado com o método "use" será feito no estilo JSON 

app.use(cors());

app.get("/usuarios", async (req, res) =>{
    try {
        const [lista] = await db.query("SELECT * FROM tbusuarios");
        res.json(lista)
    } catch (erro) {
        res.status(500).json(erro)
    }
})


app.post("/login", async (req, res) =>{
    
    if (!email || !senha) {
        alert("") //<-- parei aqui
        return 
    }
    let connection;
    try{
        const {email, senha} = req.body;
        connection = await db.getConnection();

        const [resultado] = await connection.execute("SELECT Senha FROM tbusuarios WHERE email = ?", [email]);

       if(senha === resultado[0].senha) {
        return res.status(200).json({
            mensagem: "Sucesso ao logar",
            ok: true
        })
       }
    } catch (erro) {
        return res.status(500).json(erro)
    } finally {
        if(connection){
            db.releaseConnection();
        }
    }
})

app.post("/cadastro", async (req, res) =>{ 
    
    let connection;
    console.log("deu");
    try{
        

        const {nome, email, senha, areaServico, setor, usuario, tipo, genero, pcd} = req.body;
        connection = await db.getConnection();  

        console.log("deu aqui")
        const [resultado] = await connection.execute("INSERT INTO tbusuarios (Nome, Email, Senha, areaServico, Setor, Usuario, TipoUsuario, Genero, Pcd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [nome, email, senha, areaServico, setor, usuario, tipo, genero, pcd]);
        
        res.json({ id: resultado.insertId, nome, email, areaServico, setor, usuario, tipo, genero, pcd});
    } catch (erro) {
        res.status(500).json(erro)
    } finally {
        if(connection) {
            db.releaseConnection();
        }
    }
})

app.listen(3000, () => {
    console.log("API ESTA RODANDO NA PORTA: http://localhost:3000");
})

app.get("/", (req,res) =>{
res.send("api funcionando");

})