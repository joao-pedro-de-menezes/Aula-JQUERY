const express = require("express"); // se usarmos esses CONST sem o "require", dará erro só na hora que for executar o sistema, é o erro invisivel, é obrigatorio usar require 
const cors = require("cors");
const mysql = require("mysql2/promise"); // O "/promise" serve para dizer para o banco de dados como se fosse uma promessa de um valor para ele buscar, algo que existe, é obrigatorio quando usa o "await" no sistema

// CHAMAR O MODULO db.js

const app = express(); // aqui o "app" esta sendo feito para importar os modulos detro do express para usar suas funções   

app.use(express.json); // (aqui esta usando o método "use" que estava dentro do express e que na função de cima ja foi importado pra dentro do app) e tudo que for utilizado com o método "use" será feito no estilo JSON 

app.get("/usuarios", async (req, res) =>{
    try {
        const [lista] = await db.query("SELECT * FROM tbusuarios");
        res.json(lista)
    } catch (erro) {
        res.status(500).json(erro)
    }
})

app.listen(3000, () => {
    console.log("API ESTA RODANDO NA PORTA: http://localhost:3000");
})

app.post("/cadastro", async (req, res) =>{
    try{
        const {nome, email, senha, areaServico, setor, usuario, tipoUsuario, genero, pcd} = req.body;
        const [resultado] = await db.query("INSERT INTO tbusuario (nome, email, senha, areaServico, setor, usuario, tipoUsuario, genero, pcd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [nome, email, senha, areaServico, setor, usuario, tipoUsuario, genero, pcd]);

        res.json({ id: resultado.insertId, nome, email, areaServico, setor, usuario, tipoUsuario, genero, pcd});
    } catch (erro) {
        res.status()
    }
})