const express = require("express"); // se usarmos esses CONST sem o "require", dará erro só na hora que for executar o sistema, é o erro invisivel, é obrigatorio usar require 
const cors = require("cors");
 // O "/promise" serve para dizer para o banco de dados como se fosse uma promessa de um valor para ele buscar, algo que existe, é obrigatorio quando usa o "await" no sistema

const db = require("./db")

// CHAMAR O MODULO db.js

const app = express(); // aqui o "app" esta sendo feito para importar os modulos detro do express para usar suas funções   

app.use(express.json()); // (aqui esta usando o método "use" que estava dentro do express e que na função de cima ja foi importado pra dentro do app) e tudo que for utilizado com o método "use" será feito no estilo JSON 

app.use(cors());

//////////// Método para Mostrar TODOS os usuario ///////////////
app.get("/usuarios", async (req, res) =>{
    try {
        const [lista] = await db.query("SELECT * FROM tbusuarios");
        res.json(lista)
    } catch (erro) {
        res.status(500).json(erro)
    }
})

//////////// Método para Login "POST" ///////////////
app.post("/login", async (req, res) =>{
    
    try{
        const {email, senha} = req.body;
       

        const [resultado] = await db.query("SELECT Senha FROM tbusuarios WHERE email = ? AND senha = ?", [email, senha]);

       if (senha === resultado[0].senha) {
        return res.status(200).json({
            mensagem: "Sucesso ao logar",
            ok: true,
            usuario: resultado[0]
        }) 
       } else {
        return res.status(401)({
            ok: false,
            mensagem: "Email ou Senha invalida"
        })
       }
       
    } catch (erro) {
        return res.status(500).json(erro)
    } 
})


//////////// Método para Cadastro "POST" ///////////////
app.post("/cadastro", async (req, res) =>{ 
    
    try{
        const {nome, email, senha, areaServico, setor, usuario, tipo, genero, pcd} = req.body;
    
        const [resultado] = await db.query("INSERT INTO tbusuarios (Nome, Email, Senha, areaServico, Setor, Usuario, TipoUsuario, Genero, Pcd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [nome, email, senha, areaServico, setor, usuario, tipo, genero, pcd]);
        
        res.json({ id: resultado.insertId, nome, email, areaServico, setor, usuario, tipo, genero, pcd});
    } catch (erro) {
        res.status(500).json(erro)
    } finally {
        if(connection) {
            db.releaseConnection();
        }
    }
})

//////////// Método para criação "POST" ///////////////
app.post("/projetos", async (req, res) =>{
    try {
    const {nome, detalhe, qtde} = req.body;
    const [resultado] = await db.query("INSERT INTO tbprojetos (nome, detalhe, qtde) VALUES (?, ?, ?)", [nome, detalhe, qtde]);

    return res.status(201).json({id: resultado.insertId, nome, detalhe, qtde});
    } catch (erro) { 
        res.status(500).json(erro)
    }
})

//////////// Método para VER SE A API ESTA FUNCIONANDO ///////////////
app.listen(3000, () => {
    console.log("API ESTA RODANDO NA PORTA: http://localhost:3000");
})

app.get("/", (req,res) =>{
res.send("api funcionando");

})