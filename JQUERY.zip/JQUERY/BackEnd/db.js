const mysql = require("myslq2/promise");
require("dotenv").config(); //

const db = mysql.createPool({
    host: process.env.DB_HOST,
    name: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

module.exports = db;
